# Flask To-Do List App

## Setup

1. Create a virtual environment:
   ```sh
   python -m venv venv